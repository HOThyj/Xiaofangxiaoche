#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/delay/delay.h"
#include "./SYSTEM/usart/usart.h"
#include "./BSP/LED/LED.h"
#include "./BSP/Beep/Beep.h"
#include "./BSP/KEY/KEY.h"
#include "./BSP/Servo/Servo.h"
#include "./BSP/Car/Car.h"
#include "./BSP/Fire/Fire.h"
#include "./BSP/HCSR/HCSR.h"

uint8_t KeyNum;     //�������ڽ��հ�������ı���
uint16_t Data1;

int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); /* �ж����ȼ�����2 */
    delay_init(144);                                /* ��ʱ��ʼ�� */
    usart_init(9600);                             /* ���ڳ�ʼ��Ϊ115200 */

    Beep_Init();
    Car_Init();
    Servo_Init();
    Fire_Init();
    Ultrasound_Init();
    Servo_SetAngle(90);
    while (1)
    {
        uint16_t distance = Test_Distance();
        Serial_SendNumber(distance, 3);
        if (distance < 30||Fire1_Get()== 0||Fire2_Get() == 0)
        {
            Car_Stop();
            delay_ms(1000);
            if (Fire1_Get()== 0||Fire2_Get() == 0)
            {
                Car_Stop();
                Beep_ON();
                Wind_go();
                Water_go();
            }
            else
            {
                Beep_OFF();
                Water_stop();
                Wind_stop();
                Servo_SetAngle(30);
                delay_ms(1000);
                uint16_t distance2 = Test_Distance();
                Serial_SendNumber(distance2, 3);

                if (distance2 > 30)
                {
                    Servo_SetAngle(90);
                    delay_ms(1000);
                    Self_Right();
                    delay_ms(1000);
                    Go_Ahead();
                }
                else
                {
                    Servo_SetAngle(150);
                    delay_ms(1000);
                    uint16_t distance3 = Test_Distance();
                    Serial_SendNumber(distance3, 1);

                    if (distance3 > 30)
                    {
                        Servo_SetAngle(90);
                        delay_ms(1000);
                        Self_Left();
                        delay_ms(1000);
                        Go_Ahead();
                    }
                    else
                    {
                        Servo_SetAngle(90);
                        while (1)
                        {
                        }; // ��ѭ������ִͣ��ֱ���ⲿ�¼�����
                    }
                }
            }
        }

        delay_ms(100);
    }
}


