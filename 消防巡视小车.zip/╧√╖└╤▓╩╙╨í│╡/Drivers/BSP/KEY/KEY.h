#ifndef _KEY_H
#define _KEY_H

#include "./SYSTEM/sys/sys.h"
void Key_Init(void);
uint8_t Key_GetNum(void);

#endif
