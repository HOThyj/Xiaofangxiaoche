#ifndef __HCSR_H
#define __HCSR_H

#include "./SYSTEM/sys/sys.h"

void Ultrasound_Init();
float Test_Distance();

#endif
