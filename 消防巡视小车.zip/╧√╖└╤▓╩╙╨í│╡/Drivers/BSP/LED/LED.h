#ifndef _LED_H
#define _LED_H

#include "./SYSTEM/sys/sys.h"

void LED_LSD(void);
void LED_Init(void);
void LED1_Turn(void);
void LED1_ON(void);
void LED1_OFF(void);

#endif
