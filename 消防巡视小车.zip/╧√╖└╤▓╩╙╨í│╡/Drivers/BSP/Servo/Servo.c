#include "./BSP/Servo/Servo.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/PWM/PWM.h"

void Servo_Init(void)
{
    PWM_Init();
}

void Servo_SetAngle(float Angle)
{
    PWM_2SetCompare3(Angle / 180 * 2000 + 500);
}
