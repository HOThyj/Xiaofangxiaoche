#ifndef _BEEP_H
#define _BEEP_H

#include "./SYSTEM/sys/sys.h"

void Beep_Init(void);
void Beep_ON(void);
void Beep_OFF(void);

#endif
