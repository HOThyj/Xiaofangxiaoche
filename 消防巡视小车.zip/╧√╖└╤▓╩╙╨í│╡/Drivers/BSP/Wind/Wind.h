#ifndef __WIND_H
#define __WIND_H

void Wind_Init(void);
void Wind_SetSpeed(int S);

#endif
