#ifndef __FIRE_H
#define __FIRE_H
#include "./SYSTEM/sys/sys.h"

void Fire_Init(void);
uint8_t Fire1_Get(void);
uint8_t Fire2_Get(void);

#endif
