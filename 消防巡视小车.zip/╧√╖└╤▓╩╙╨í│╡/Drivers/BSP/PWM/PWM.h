#ifndef __PWM_H
#define __PWM_H
#include "./BSP/PWM/PWM.h"

void PWM_Init(void);
void PWM_SetCompare3(int Compare);
void PWM_SetCompare4(int Compare);
void PWM_2SetCompare3(int Compare);
void PWM_SetCompare2(int Compare);
void PWM_SetCompare1(int Compare);

#endif
