#include "./BSP/Car/Car.h"
#include "./BSP/Motor/Motor.h"
#include "./BSP/Water/Water.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/Wind/Wind.h"
#include "./BSP/PWM/PWM.h"

void Car_Init(){
    Motor_Init();
    Water_Init();
    Wind_Init();
}
void Go_Ahead(){
    Motor_SetLeftSpeed(70);
    Motor_SetRightSpeed(70);
}
void Go_Back(){
    Motor_SetLeftSpeed(-70);
    Motor_SetRightSpeed(-70);
}
void Turn_Left(){
    Motor_SetLeftSpeed(0);
    Motor_SetRightSpeed(70);
}
void Turn_Right(){
    Motor_SetRightSpeed(0);
    Motor_SetLeftSpeed(70);
}
void Self_Left(){
    Motor_SetLeftSpeed(-75);
    Motor_SetRightSpeed(75);
}
void Self_Right(){
    Motor_SetLeftSpeed(75);
    Motor_SetRightSpeed(-75);
}
void Car_Stop(){
    Motor_SetLeftSpeed(0);
    Motor_SetRightSpeed(0);
}
void Water_go(){
    Water_SetSpeed(70);
}
void Water_stop(){
    Water_SetSpeed(0);
}
void Wind_go(){
    Wind_SetSpeed(60);
}
void Wind_stop(){
    Wind_SetSpeed(0);
}


