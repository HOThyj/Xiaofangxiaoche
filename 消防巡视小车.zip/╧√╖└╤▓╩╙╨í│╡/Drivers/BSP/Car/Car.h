#ifndef __CAR_H
#define __CAR_H

void Car_Init();
void Self_Right();
void Self_Left();
void Turn_Right();
void Turn_Left();
void Go_Back();
void Go_Ahead();
void Car_Stop();
void Water_go();
void Water_stop();
void Wind_go();
void Wind_stop();

#endif
