#ifndef __WATER_H
#define __WATER_H

void Water_Init(void);
void Water_SetSpeed(int S);

#endif
